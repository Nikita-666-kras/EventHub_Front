<template>
    <LentaLayout>
  <!-- <NavBar /> -->
  <div class="main-wrapper">
    <slot />
  </div>
    </LentaLayout>
</template>
<script>
import LentaLayout from '@/page/lenta.vue'
</script>